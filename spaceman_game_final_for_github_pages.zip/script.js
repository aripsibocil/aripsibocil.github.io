let balance = 1000;
let multiplier = 1.00;
let crashPoint;
let interval;
let username = "";

document.getElementById("start-btn").addEventListener("click", () => {
  username = document.getElementById("username").value;
  if(username.trim() === "") {
    alert("Masukkan username!");
    return;
  }
  document.getElementById("player-name").textContent = username;
  document.getElementById("login-screen").style.display = "none";
  document.getElementById("game-screen").style.display = "block";
});

document.getElementById("bet-btn").addEventListener("click", () => {
  let bet = parseFloat(document.getElementById("bet-amount").value);
  if(isNaN(bet) || bet <= 0) {
    alert("Masukkan taruhan yang valid!");
    return;
  }
  if(bet > balance) {
    alert("Saldo tidak cukup!");
    return;
  }
  balance -= bet;
  document.getElementById("balance").textContent = balance.toFixed(2);
  startRound(bet);
});

function startRound(bet) {
  new Audio('sounds/start.mp3').play();
  crashPoint = (Math.random() * 9 + 1).toFixed(2);
  multiplier = 1.00;
  interval = setInterval(() => {
    multiplier += 0.01;
    document.getElementById('multiplier-display').textContent = 'x' + multiplier.toFixed(2);
    if(multiplier >= crashPoint) {
      crash();
    }
  }, 50);
}

function crash() {
  clearInterval(interval);
  new Audio('sounds/crash.mp3').play();
  alert(`Crash di x${crashPoint}`);
}
